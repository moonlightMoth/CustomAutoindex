package productionline;

public enum ItemType {
    AU, VI, AM, VM;
}
