package productionline;

public class AudioPlayerDriver {

    public static void main (String[] args)
    {
        AudioPlayer audioPlayer = new AudioPlayer("NAME", "audioPrikol");

        audioPlayer.play();
        audioPlayer.next();
        audioPlayer.previous();
        audioPlayer.stop();
        System.out.println(audioPlayer);
    }
}
