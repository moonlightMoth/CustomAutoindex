package productionline;

public enum MonitorType {
    LCD, LED
}
