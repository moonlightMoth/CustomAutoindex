package productionline;

public class ScreenDriver {

    public static void main(String[] args)
    {
        Screen screen = new Screen("600x400",40,22);

        System.out.println(screen.getRefreshRate());
        System.out.println(screen.getResolution());
        System.out.println(screen.getResponseTime());

        System.out.println(screen);
    }
}
