package productionline;

public interface ScreenSpec {
    String getResolution();
    int getRefreshRate();
    int getResponseTime();
}
